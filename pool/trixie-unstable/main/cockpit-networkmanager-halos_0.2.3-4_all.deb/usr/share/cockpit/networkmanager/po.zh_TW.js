cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 active zone": [
  null,
  "$0 個已啟用的區域"
 ],
 "$0 day": [
  null,
  "$0 天"
 ],
 "$0 exited with code $1": [
  null,
  "$0 結束執行並回傳 $1"
 ],
 "$0 failed": [
  null,
  "$0 失敗"
 ],
 "$0 hour": [
  null,
  "$0 小時"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 在任何軟體庫中都未提供。"
 ],
 "$0 key changed": [
  null,
  "金鑰 $0 已被更改"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 被 $1 訊號終止執行"
 ],
 "$0 minute": [
  null,
  "$0 分鐘"
 ],
 "$0 month": [
  null,
  "$0 月"
 ],
 "$0 week": [
  null,
  "$0 週"
 ],
 "$0 will be installed.": [
  null,
  "$0 將會被安裝。"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "$0 zone": [
  null,
  "$0 區域"
 ],
 "1 day": [
  null,
  "1 天"
 ],
 "1 hour": [
  null,
  "1 小時"
 ],
 "1 minute": [
  null,
  "1 分鐘"
 ],
 "1 week": [
  null,
  "1週"
 ],
 "20 minutes": [
  null,
  "20 分鐘"
 ],
 "40 minutes": [
  null,
  "40 分鐘"
 ],
 "5 minutes": [
  null,
  "5 分鐘"
 ],
 "6 hours": [
  null,
  "6 小時"
 ],
 "60 minutes": [
  null,
  "60 分鐘"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "未在 $0 上安裝相容的 Cockpit 版本。"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "網路 Bond (network bond) 將數個網路界面結合至一個邏輯介面中，提供更高的網路流通量或冗餘。"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "將為了在 $2 上的 $1 建立一個於 $0 的新 SSH 金鑰，且其將會被加到 $5 上 $4 的 $3 檔案中。"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "ARP監控"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "Absent": [
  null,
  "不存在"
 ],
 "Acceptable password": [
  null,
  "可接受的密碼強度"
 ],
 "Actions": [
  null,
  "動作"
 ],
 "Active": [
  null,
  "啟用"
 ],
 "Active backup": [
  null,
  "啟用與備用 (Active backup)"
 ],
 "Adaptive load balancing": [
  null,
  "適應性負載平衡"
 ],
 "Adaptive transmit load balancing": [
  null,
  "適應性傳輸負載平衡"
 ],
 "Add": [
  null,
  "加入"
 ],
 "Add $0": [
  null,
  "新增 $0"
 ],
 "Add DNS server": [
  null,
  "新增 DNS 伺服器"
 ],
 "Add VLAN": [
  null,
  "新增 VLAN"
 ],
 "Add VPN": [
  null,
  "新增 VPN"
 ],
 "Add WireGuard VPN": [
  null,
  "新增 WireGuard VPN"
 ],
 "Add a new zone": [
  null,
  "新增新的區域"
 ],
 "Add address": [
  null,
  "新增位址"
 ],
 "Add bond": [
  null,
  "新增 bond"
 ],
 "Add bridge": [
  null,
  "新增橋接"
 ],
 "Add member": [
  null,
  "新增成員"
 ],
 "Add new zone": [
  null,
  "新增區域"
 ],
 "Add peer": [
  null,
  "新增 peer"
 ],
 "Add ports": [
  null,
  "新增通訊埠"
 ],
 "Add ports to $0 zone": [
  null,
  "新增通訊埠到 $0 區域"
 ],
 "Add route": [
  null,
  "新增路由"
 ],
 "Add search domain": [
  null,
  "新增搜尋網域"
 ],
 "Add services": [
  null,
  "新增服務"
 ],
 "Add services to $0 zone": [
  null,
  "新增服務到 $0 區域"
 ],
 "Add services to zone $0": [
  null,
  "新增服務到 $0 區域"
 ],
 "Add team": [
  null,
  "新增 team"
 ],
 "Add zone": [
  null,
  "新增區域"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "新增 $0 將中斷與伺服器的連線，屆時管理介面將無法使用。"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "新增自訂連接埠將會重新載入 firewalld。重新載入將導致任何僅適用於執行階段的設定遺失！"
 ],
 "Additional DNS $val": [
  null,
  "額外的DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "額外的 DNS 搜尋網域 $val"
 ],
 "Additional address $val": [
  null,
  "額外的位址 $val"
 ],
 "Additional packages:": [
  null,
  "額外軟體包："
 ],
 "Additional ports": [
  null,
  "額外連接埠"
 ],
 "Address": [
  null,
  "位址"
 ],
 "Address $val": [
  null,
  "位址 $val"
 ],
 "Addresses": [
  null,
  "位址"
 ],
 "Addresses are not formatted correctly": [
  null,
  "位址的格式不正確"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "使用 Cockpit 網頁控制台進行管理"
 ],
 "Advanced TCA": [
  null,
  "進階 TCA"
 ],
 "All-in-one": [
  null,
  "一體成型電腦"
 ],
 "Allowed IPs": [
  null,
  "允許的 IP"
 ],
 "Allowed addresses": [
  null,
  "允許的位址"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible 角色文件"
 ],
 "Authenticating": [
  null,
  "認證"
 ],
 "Authentication": [
  null,
  "核對"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "需要驗證才可以透過 Cockpit 網頁控制台執行高權限的工作"
 ],
 "Authorize SSH key": [
  null,
  "授權 SSH 金鑰"
 ],
 "Automatic": [
  null,
  "自動"
 ],
 "Automatic (DHCP only)": [
  null,
  "自動（僅限DHCP）"
 ],
 "Automatically using NTP": [
  null,
  "自動使用 NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "自動使用額外的 NTP 伺服器"
 ],
 "Automatically using specific NTP servers": [
  null,
  "自動使用指定的 NTP 伺服器"
 ],
 "Automation script": [
  null,
  "自動化腳本"
 ],
 "Balancer": [
  null,
  "平衡器"
 ],
 "Blade": [
  null,
  "刀鋒"
 ],
 "Blade enclosure": [
  null,
  "刀鋒外殼"
 ],
 "Bond": [
  null,
  "Bond"
 ],
 "Bridge": [
  null,
  "橋接"
 ],
 "Bridge port": [
  null,
  "橋接埠"
 ],
 "Bridge port settings": [
  null,
  "橋接埠設定"
 ],
 "Broadcast": [
  null,
  "廣播"
 ],
 "Broken configuration": [
  null,
  "設定檔損壞"
 ],
 "Bus expansion chassis": [
  null,
  "匯流排擴充機殼"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Cannot forward login credentials": [
  null,
  "無法轉發登入憑證"
 ],
 "Cannot schedule event in the past": [
  null,
  "無法安排過去的活動"
 ],
 "Carrier": [
  null,
  "載體"
 ],
 "Change": [
  null,
  "變更"
 ],
 "Change system time": [
  null,
  "變更系統時間"
 ],
 "Change the settings": [
  null,
  "更改設定"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "重新安裝作業系統通常會導致金鑰變更。然而，未預期的變更可能是第三方嘗試竊聽連線的跡象。"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "更改設定將中斷與伺服器的連線，並使管理介面無法使用。"
 ],
 "Checking IP": [
  null,
  "檢查IP"
 ],
 "Checking installed software": [
  null,
  "正在檢查已安裝的軟體"
 ],
 "Clear input value": [
  null,
  "清除輸入的值"
 ],
 "Close": [
  null,
  "關閉"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit 的 NetworkManager 與 Firewalld 設定"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit 無法聯絡指定的主機。"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit 是一個伺服器管理器，它可以讓您透過網頁瀏覽器輕鬆管理 Linux 伺服器。同時運用終端機與網頁工具是沒有問題的。由 Cockpit 啟動的服務可在終端機中被停止。同樣地，若終端機中發生錯誤時，也可以在 Cockpit 的紀錄檔日誌介面中看到。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit 與該系統上的軟體不相容。"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit 未安裝"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit 未安裝在系統上。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit 非常適合新的系統管理員，使他們能夠輕鬆執行簡單的任務，如：儲存空間管理、檢查日誌紀錄及啟動與停止服務。您可以同時監控和管理多個伺服器。只需輕鬆的新增它們，您的機器們將會關心彼此的狀況。"
 ],
 "Collect and package diagnostic and support data": [
  null,
  "收集並封裝診斷與支援資料"
 ],
 "Collect kernel crash dumps": [
  null,
  "蒐集核心當機傾印"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "可使用逗號分隔的連接埠、範圍和服務"
 ],
 "Compact PCI": [
  null,
  "緊密型 PCI"
 ],
 "Configuring": [
  null,
  "正在設定"
 ],
 "Configuring IP": [
  null,
  "正在設定 IP"
 ],
 "Confirm key password": [
  null,
  "確認金鑰密碼"
 ],
 "Confirm removal of $0": [
  null,
  "確認移除 $0"
 ],
 "Connect automatically": [
  null,
  "自動連線"
 ],
 "Connection has timed out.": [
  null,
  "連線已逾時。"
 ],
 "Connection will be lost": [
  null,
  "連線將中斷"
 ],
 "Convertible": [
  null,
  "二合一電腦"
 ],
 "Copied": [
  null,
  "已複製"
 ],
 "Copy": [
  null,
  "複製"
 ],
 "Copy to clipboard": [
  null,
  "複製到剪貼簿"
 ],
 "Create $0": [
  null,
  "建立 $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "建立新的 SSH 金鑰並對其授權"
 ],
 "Create it": [
  null,
  "仍要建立"
 ],
 "Create new task file with this content.": [
  null,
  "以此內容建立新的工作檔案。"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "建立此 $0 將中斷與伺服器的連線，且會使管理介面無法使用。"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "自訂連接埠"
 ],
 "Custom zones": [
  null,
  "自訂區域"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "DNS 搜尋網域"
 ],
 "DNS search domains $val": [
  null,
  "DNS 搜尋網域 $val"
 ],
 "Deactivating": [
  null,
  "停用"
 ],
 "Delay": [
  null,
  "延遲"
 ],
 "Delete": [
  null,
  "刪除"
 ],
 "Delete $0": [
  null,
  "刪除 $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "刪除 $0 將中斷與伺服器的連線，且會無法使用管理介面。"
 ],
 "Description": [
  null,
  "說明"
 ],
 "Desktop": [
  null,
  "桌機"
 ],
 "Detachable": [
  null,
  "可拆開"
 ],
 "Diagnostic reports": [
  null,
  "診斷報告"
 ],
 "Disable the firewall": [
  null,
  "停用防火牆"
 ],
 "Disabled": [
  null,
  "已停用"
 ],
 "Docking station": [
  null,
  "擴充基座"
 ],
 "Downloading $0": [
  null,
  "下載 $0"
 ],
 "Dual rank": [
  null,
  "雙 Rank"
 ],
 "Edit": [
  null,
  "編輯"
 ],
 "Edit VLAN settings": [
  null,
  "編輯 VLAN 設定"
 ],
 "Edit WireGuard VPN": [
  null,
  "編輯 WireGuard VPN"
 ],
 "Edit bond settings": [
  null,
  "編輯 bond 設定"
 ],
 "Edit bridge settings": [
  null,
  "編輯橋接設定"
 ],
 "Edit custom service in $0 zone": [
  null,
  "編輯 $0 區域的自訂服務"
 ],
 "Edit rules and zones": [
  null,
  "編輯規則與區域"
 ],
 "Edit service": [
  null,
  "編輯服務"
 ],
 "Edit service $0": [
  null,
  "編輯服務 $0"
 ],
 "Edit team settings": [
  null,
  "編輯 team 設定"
 ],
 "Embedded PC": [
  null,
  "嵌入式PC"
 ],
 "Enable or disable the device": [
  null,
  "啟用或停用裝置"
 ],
 "Enable service": [
  null,
  "啟用服務"
 ],
 "Enable the firewall": [
  null,
  "啟用防火牆"
 ],
 "Enabled": [
  null,
  "已啟用"
 ],
 "Endpoint": [
  null,
  "端點"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "作為「伺服器」的端點須被指定為 主機:連接埠 ，除此之外可不填寫。"
 ],
 "Enter a valid MAC address": [
  null,
  "輸入有效的 MAC 位址"
 ],
 "Entire subnet": [
  null,
  "整個子網路"
 ],
 "Ethernet MAC": [
  null,
  "以太網MAC"
 ],
 "Ethernet MTU": [
  null,
  "以太網MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool的"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "例如： 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "例如： 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "優秀的密碼"
 ],
 "Expansion chassis": [
  null,
  "擴充機殼"
 ],
 "Failed": [
  null,
  "失敗"
 ],
 "Failed to add port": [
  null,
  "新增連接埠失敗"
 ],
 "Failed to add service": [
  null,
  "新增服務失敗"
 ],
 "Failed to add zone": [
  null,
  "新增區域失敗"
 ],
 "Failed to change password": [
  null,
  "無法更改密碼"
 ],
 "Failed to edit service": [
  null,
  "編輯服務失敗"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "啟用 firewalld 中的 $0 失敗"
 ],
 "Failed to save settings": [
  null,
  "儲存設定失敗"
 ],
 "Filter services": [
  null,
  "過濾服務"
 ],
 "Firewall": [
  null,
  "防火牆"
 ],
 "Firewall is not available": [
  null,
  "防火牆無法使用"
 ],
 "Forward delay $forward_delay": [
  null,
  "轉發延遲 $forward_delay"
 ],
 "Gateway": [
  null,
  "閘道"
 ],
 "General": [
  null,
  "一般"
 ],
 "Generated": [
  null,
  "產生的"
 ],
 "Go to now": [
  null,
  "移至現在"
 ],
 "Group": [
  null,
  "群組"
 ],
 "Hair pin mode": [
  null,
  "Hair pin 模式"
 ],
 "Hairpin mode": [
  null,
  "Hairpin 模式"
 ],
 "Handheld": [
  null,
  "手持裝置"
 ],
 "Hello time $hello_time": [
  null,
  "Hello 時間 $hello_time"
 ],
 "Hide confirmation password": [
  null,
  "隱藏確認密碼"
 ],
 "Hide password": [
  null,
  "隱藏密碼"
 ],
 "Host key is incorrect": [
  null,
  "主機金鑰不正確"
 ],
 "ID": [
  null,
  "ID"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "IP address": [
  null,
  "IP 位址"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "具有路由前綴的 IP 位址。用逗號以分隔多個數值。例如： 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 settings": [
  null,
  "IPv4 設定"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "IPv6 設定"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "如果未填寫，將會依所相聯的連接埠服務與連接埠號碼產生 ID"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "如果指紋相符，點選「信任並新增主機」。否則，不要連線並聯絡您的管理人員。"
 ],
 "Ignore": [
  null,
  "忽略"
 ],
 "Inactive": [
  null,
  "未啟用"
 ],
 "Included services": [
  null,
  "包含的服務"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "連入請求預設會被阻擋。連出請求不會被阻擋。"
 ],
 "Install": [
  null,
  "安裝"
 ],
 "Install software": [
  null,
  "安裝軟體"
 ],
 "Installing $0": [
  null,
  "正在安裝 $0"
 ],
 "Interface": [
  null,
  "介面"
 ],
 "Interface members": [
  null,
  "介面成員"
 ],
 "Interfaces": [
  null,
  "介面"
 ],
 "Internal error": [
  null,
  "內部錯誤"
 ],
 "Invalid address $0": [
  null,
  "無效的位址 $0"
 ],
 "Invalid date format": [
  null,
  "日期格式無效"
 ],
 "Invalid date format and invalid time format": [
  null,
  "無效的日期與時間格式"
 ],
 "Invalid file permissions": [
  null,
  "檔案權限無效"
 ],
 "Invalid metric $0": [
  null,
  "指標無效 $0"
 ],
 "Invalid port number": [
  null,
  "無效的連接埠號碼"
 ],
 "Invalid prefix $0": [
  null,
  "無效的前綴 $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "無效的前綴或網路遮罩 $0"
 ],
 "Invalid range": [
  null,
  "無效的範圍"
 ],
 "Invalid time format": [
  null,
  "時間格式無效"
 ],
 "Invalid timezone": [
  null,
  "無效的時區"
 ],
 "IoT gateway": [
  null,
  "物聯網閘道"
 ],
 "Keep connection": [
  null,
  "維持連線"
 ],
 "Kernel dump": [
  null,
  "核心傾印"
 ],
 "Key password": [
  null,
  "金鑰密碼"
 ],
 "LACP key": [
  null,
  "LACP 金鑰"
 ],
 "Laptop": [
  null,
  "筆記型電腦"
 ],
 "Learn more": [
  null,
  "了解更多"
 ],
 "Link down delay": [
  null,
  "線路斷線延遲"
 ],
 "Link local": [
  null,
  "連結本地"
 ],
 "Link monitoring": [
  null,
  "線路監控"
 ],
 "Link up delay": [
  null,
  "線路連線延遲"
 ],
 "Link watch": [
  null,
  "線路監看"
 ],
 "Listen port": [
  null,
  "接聽連接埠"
 ],
 "Listen port must be a number": [
  null,
  "接聽連接埠必須是一個數字"
 ],
 "Load balancing": [
  null,
  "負載均衡"
 ],
 "Loading system modifications...": [
  null,
  "讀取系統變更中…"
 ],
 "Log in": [
  null,
  "登入"
 ],
 "Log in to $0": [
  null,
  "登入至 $0"
 ],
 "Log messages": [
  null,
  "記錄訊息"
 ],
 "Login failed": [
  null,
  "登入失敗"
 ],
 "Low profile desktop": [
  null,
  "尺寸較小的桌上型電腦"
 ],
 "Lunch box": [
  null,
  "午餐盒"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (建議)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU 必須是正數"
 ],
 "Main server chassis": [
  null,
  "主伺服器機殼"
 ],
 "Manage storage": [
  null,
  "管理儲存空間"
 ],
 "Managed interfaces": [
  null,
  "已接管的介面"
 ],
 "Manual": [
  null,
  "手動"
 ],
 "Manually": [
  null,
  "手動"
 ],
 "Maximum message age $max_age": [
  null,
  "最大訊息壽命 $max_age"
 ],
 "Message to logged in users": [
  null,
  "給已登入使用者的訊息"
 ],
 "Metric": [
  null,
  "指標度量"
 ],
 "Mini PC": [
  null,
  "迷你電腦"
 ],
 "Mini tower": [
  null,
  "迷你塔"
 ],
 "Mode": [
  null,
  "模式"
 ],
 "Monitoring interval": [
  null,
  "監控間隔"
 ],
 "Monitoring targets": [
  null,
  "監控目標"
 ],
 "Multi-system chassis": [
  null,
  "多系統機殼"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "可使用逗號或空格作為分隔符號來指定多個位址。"
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "NTP server": [
  null,
  "NTP 伺服器"
 ],
 "Name": [
  null,
  "名稱"
 ],
 "Need at least one NTP server": [
  null,
  "至少需要一台 NTP 伺服器"
 ],
 "Network bond": [
  null,
  "網路 bond"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "網路裝置與圖表需要 NetworkManager"
 ],
 "Network logs": [
  null,
  "網路日誌紀錄"
 ],
 "NetworkManager is not installed": [
  null,
  "未安裝 NetworkManager"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager 非執行中"
 ],
 "Networking": [
  null,
  "網路"
 ],
 "New password was not accepted": [
  null,
  "不接受新密碼"
 ],
 "No": [
  null,
  "否"
 ],
 "No carrier": [
  null,
  "無載體"
 ],
 "No delay": [
  null,
  "沒有延遲"
 ],
 "No description available": [
  null,
  "沒有可用的說明"
 ],
 "No peers added.": [
  null,
  "未新增任何 peer。"
 ],
 "No results found": [
  null,
  "沒有找到結果"
 ],
 "No such file or directory": [
  null,
  "無此檔案或目錄"
 ],
 "No system modifications": [
  null,
  "沒有系統異動"
 ],
 "None": [
  null,
  "無"
 ],
 "Not a valid private key": [
  null,
  "不是有效的私鑰"
 ],
 "Not authorized to disable the firewall": [
  null,
  "未授權停用防火牆"
 ],
 "Not authorized to enable the firewall": [
  null,
  "未授權啟用防火牆"
 ],
 "Not available": [
  null,
  "無法使用"
 ],
 "Not permitted to configure network devices": [
  null,
  "未被允許設定網路裝置"
 ],
 "Not permitted to perform this action.": [
  null,
  "不允許執行此操作。"
 ],
 "Not synchronized": [
  null,
  "不同步"
 ],
 "Notebook": [
  null,
  "筆記型"
 ],
 "Occurrences": [
  null,
  "發生次數"
 ],
 "Ok": [
  null,
  "確定"
 ],
 "Old password not accepted": [
  null,
  "舊密碼不被接受"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "安裝Cockpit後，使用“systemctl enable --now cockpit.socket”啟用它。"
 ],
 "Options": [
  null,
  "選項"
 ],
 "Other": [
  null,
  "其它"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit 當掉了"
 ],
 "Parent": [
  null,
  "上層"
 ],
 "Parent $parent": [
  null,
  "上層 $parent"
 ],
 "Part of $0": [
  null,
  "$0 的一部分"
 ],
 "Passive": [
  null,
  "被動"
 ],
 "Password": [
  null,
  "密碼"
 ],
 "Password is not acceptable": [
  null,
  "密碼是不可接受的"
 ],
 "Password is too weak": [
  null,
  "密碼太弱了"
 ],
 "Password not accepted": [
  null,
  "密碼不被接受"
 ],
 "Paste": [
  null,
  "貼上"
 ],
 "Paste error": [
  null,
  "貼上時發生錯誤"
 ],
 "Paste existing key": [
  null,
  "貼上既有的金鑰"
 ],
 "Path cost": [
  null,
  "路徑成本"
 ],
 "Path cost $path_cost": [
  null,
  "路徑成本 $path_cost"
 ],
 "Path to file": [
  null,
  "檔案路徑"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Peer #$0 含有無效的端點連接埠。連接埠必須為數字。"
 ],
 "Peers": [
  null,
  "Peers"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Peers 是連線到這部主機的其他主機。來自其他主機的公鑰將於彼此之間共享。"
 ],
 "Peripheral chassis": [
  null,
  "週邊設備機殼"
 ],
 "Permanent": [
  null,
  "永久"
 ],
 "Pick date": [
  null,
  "選擇日期"
 ],
 "Ping interval": [
  null,
  "Ping 間隔"
 ],
 "Ping target": [
  null,
  "Ping 目標"
 ],
 "Pizza box": [
  null,
  "披薩盒"
 ],
 "Please install the $0 package": [
  null,
  "請安裝 $0 軟體包"
 ],
 "Portable": [
  null,
  "手提"
 ],
 "Ports": [
  null,
  "連接埠"
 ],
 "Prefix length": [
  null,
  "前綴長度"
 ],
 "Prefix length or netmask": [
  null,
  "前綴長度或網路遮罩"
 ],
 "Preparing": [
  null,
  "正在準備"
 ],
 "Present": [
  null,
  "存在"
 ],
 "Preserve": [
  null,
  "保留"
 ],
 "Primary": [
  null,
  "主要"
 ],
 "Priority": [
  null,
  "優先等級"
 ],
 "Priority $priority": [
  null,
  "優先度 $priority"
 ],
 "Private key": [
  null,
  "私鑰"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "以 ssh-add 提示輸入已逾時"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "以 ssh-keygen 提示輸入已逾時"
 ],
 "Public key": [
  null,
  "公鑰"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "公鑰將於輸入有效的私鑰後產生"
 ],
 "RAID chassis": [
  null,
  "RAID 機殼"
 ],
 "Rack mount chassis": [
  null,
  "機架式機殼"
 ],
 "Random": [
  null,
  "隨機"
 ],
 "Range": [
  null,
  "範圍"
 ],
 "Range must be strictly ordered": [
  null,
  "範圍必須被嚴格排序"
 ],
 "Reboot": [
  null,
  "重新開機"
 ],
 "Receiving": [
  null,
  "正在接收"
 ],
 "Regenerate": [
  null,
  "重新產生"
 ],
 "Removals:": [
  null,
  "移除："
 ],
 "Remove $0": [
  null,
  "移除 $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "從 $1 區域移除 $0 服務"
 ],
 "Remove item": [
  null,
  "移除項目"
 ],
 "Remove service $0": [
  null,
  "移除 $0 服務"
 ],
 "Remove zone $0": [
  null,
  "移除 $0 區域"
 ],
 "Removing $0": [
  null,
  "正在移除 $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "移除 $0 將中斷與伺服器的連線，且會讓管理介面無法使用。"
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "移除 cockpit 服務將可能導致再也無法連到網頁控制台。請務必確定此區域不會套用到您目前的網頁控制台連線。"
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "移除區域將會刪除其內的所有服務。"
 ],
 "Restoring connection": [
  null,
  "正在恢復連線"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Routes": [
  null,
  "路由"
 ],
 "Row expansion": [
  null,
  "展開橫列"
 ],
 "Row select": [
  null,
  "選擇列"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "由受信任的網路或親自到場於遠端機器上執行此指令："
 ],
 "Runner": [
  null,
  "執行者"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH 金鑰"
 ],
 "SSH key login": [
  null,
  "SSH 金鑰登入"
 ],
 "STP forward delay": [
  null,
  "STP 轉發延遲"
 ],
 "STP hello time": [
  null,
  "STP hello 時間"
 ],
 "STP maximum message age": [
  null,
  "STP 最大訊息壽命"
 ],
 "STP priority": [
  null,
  "STP 優先度"
 ],
 "Save": [
  null,
  "儲存"
 ],
 "Sealed-case PC": [
  null,
  "密封式PC"
 ],
 "Search domain": [
  null,
  "搜尋網域"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux 設定與疑難排解"
 ],
 "Select an option": [
  null,
  "選擇選項"
 ],
 "Select method": [
  null,
  "選擇方法"
 ],
 "Sending": [
  null,
  "傳送"
 ],
 "Server": [
  null,
  "伺服器"
 ],
 "Server has closed the connection.": [
  null,
  "伺服器已關閉連線。"
 ],
 "Service": [
  null,
  "服務管理"
 ],
 "Services": [
  null,
  "服務"
 ],
 "Set time": [
  null,
  "設定時間"
 ],
 "Set to": [
  null,
  "調成"
 ],
 "Shared": [
  null,
  "共享"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "顯示確認密碼"
 ],
 "Show password": [
  null,
  "顯示密碼"
 ],
 "Shut down": [
  null,
  "關機"
 ],
 "Single rank": [
  null,
  "單 Rank"
 ],
 "Sorted from least to most trusted": [
  null,
  "依最不受信任至最受信任排序"
 ],
 "Space-saving computer": [
  null,
  "節省空間的計算機"
 ],
 "Spanning tree protocol": [
  null,
  "生成樹協議"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "生成樹協定 (STP)"
 ],
 "Specific time": [
  null,
  "特定的時間"
 ],
 "Stable": [
  null,
  "穩定"
 ],
 "Start service": [
  null,
  "開始服務"
 ],
 "Status": [
  null,
  "狀態"
 ],
 "Stick PC": [
  null,
  "堅持使用PC"
 ],
 "Sticky": [
  null,
  "黏"
 ],
 "Storage": [
  null,
  "儲存裝置"
 ],
 "Strong password": [
  null,
  "強密碼"
 ],
 "Sub-Chassis": [
  null,
  "子機殼"
 ],
 "Sub-Notebook": [
  null,
  "小筆電"
 ],
 "Switch off $0": [
  null,
  "關掉 $0"
 ],
 "Switch on $0": [
  null,
  "打開 $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "關掉 $0 將中斷與伺服器的連線，且將使管理介面無法使用。"
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "打開 $0 將中斷與伺服器的連線，且使管理介面無法使用。"
 ],
 "Synchronized": [
  null,
  "同步"
 ],
 "Synchronized with $0": [
  null,
  "已與 $0 同步"
 ],
 "Synchronizing": [
  null,
  "同步中"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "平板電腦"
 ],
 "Team": [
  null,
  "Team"
 ],
 "Team port": [
  null,
  "Team 埠"
 ],
 "Team port settings": [
  null,
  "Team 埠設定"
 ],
 "Testing connection": [
  null,
  "正在測試連線"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 上 $1 的 SSH 金鑰 $0 將會被新增至 $5 上 $4 的 $3 檔案中。"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH 金鑰 $0 將會於剩餘的工作階段可供使用，也將會可用於登入其他主機。"
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "登入 $0 的 SSH 所用的金鑰受到密碼保護，且該主機並不允許使用密碼登入。請於 $1 提供該金鑰的密碼。"
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "登入 $0 的 SSH 金鑰受到保護。您可以用您的登入密碼、或提供前述金鑰的密碼於 $1 以便登入。"
 ],
 "The cockpit service is automatically included": [
  null,
  "cockpit 服務將自動包含於其中"
 ],
 "The fingerprint should match:": [
  null,
  "指紋應該相符："
 ],
 "The key password can not be empty": [
  null,
  "金鑰密碼不可為空值"
 ],
 "The key passwords do not match": [
  null,
  "金鑰密碼不相符"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "登入的使用者沒有檢視系統變更所需的權限"
 ],
 "The password can not be empty": [
  null,
  "密碼不可為空值"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "產生的指紋可放心以公開方式分享，包含電子郵件。"
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "產生的指紋可放心以公開方式分享，包含電子郵件。如果您需要其他人士為您進行驗證，那些人士可使用任何方法傳送結果。"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "伺服器拒絕使用任何受支援的方式進行驗證。"
 ],
 "There are no active services in this zone": [
  null,
  "此區域中沒有運作中的服務"
 ],
 "This device cannot be managed here.": [
  null,
  "此裝置無法在此處被管理。"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "此工具設定 SELinux 政策且能協助瞭解與處理政策違規事件。"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "此工具設定系統以儲存核心當機傾印。它支援 \"本機\" (磁碟)、\"ssh\"，與 \"nfs\" 作為傾印儲存目的地。"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "此工具會從運作中的系統產生一個具有診斷資訊與設定的封存檔案。這個封存檔案可被存在本機、或為了紀錄與追蹤用途集中存放，也可能被傳送至技術支援代表、開發者或系統管理員以協助排除技術障礙與對程式除錯。"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "此工具管理本機儲存空間，如檔案系統、LVM2 磁碟區群組與掛載 NFS。"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "此工具使用 NetworkManager 與 Firewalld 管理網路功能，如 bond、橋接、teams、VLAN 和防火牆。NetworkManager 與 Ubuntu 預設的 systemd-networkd 及 Debian 的 ifupdown scripts 皆不相容。"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "這個區域包含 cockpit 服務。請確認這個區域不適用於您目前的網頁控制台連線。"
 ],
 "Time zone": [
  null,
  "時區"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "要確保您的連線未被惡意的第三方截取，請驗證主機金鑰指紋："
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "要驗證指紋，請實際坐在機器前或透過可信任的網路於 $0 上執行以下指令："
 ],
 "Toggle date picker": [
  null,
  "打開/關閉日期挑選器"
 ],
 "Too much data": [
  null,
  "資料過多"
 ],
 "Total size: $0": [
  null,
  "總大小： $0"
 ],
 "Tower": [
  null,
  "塔"
 ],
 "Transmitting": [
  null,
  "正在傳送"
 ],
 "Troubleshoot…": [
  null,
  "疑難排解…"
 ],
 "Trust and add host": [
  null,
  "信任並新增主機"
 ],
 "Trust level": [
  null,
  "信任等級"
 ],
 "Trying to synchronize with $0": [
  null,
  "正在嘗試與 $0 同步"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "無法使用 SSH 金鑰驗證登入 $0。請提供密碼。"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "無法登入 $0 。該主機不接受密碼登入、或您的任何 SSH 金鑰。"
 ],
 "Unexpected error": [
  null,
  "未預期的錯誤"
 ],
 "Unknown": [
  null,
  "不明"
 ],
 "Unknown \"$0\"": [
  null,
  "未知“$0“"
 ],
 "Unknown configuration": [
  null,
  "未知的設定"
 ],
 "Unknown host: $0": [
  null,
  "未知的主機： $0"
 ],
 "Unknown service name": [
  null,
  "未知服務名稱"
 ],
 "Unmanaged interfaces": [
  null,
  "未接管的介面"
 ],
 "Untrusted host": [
  null,
  "不受信任的主機"
 ],
 "Use $0": [
  null,
  "使用 $0"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "VLAN ID"
 ],
 "Verify fingerprint": [
  null,
  "驗證指紋"
 ],
 "View all logs": [
  null,
  "檢視所有日誌紀錄檔"
 ],
 "View automation script": [
  null,
  "檢視自動化 script"
 ],
 "Visit firewall": [
  null,
  "前往防火牆"
 ],
 "Waiting": [
  null,
  "正在等待"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "等待其他軟體管理動作完成"
 ],
 "Weak password": [
  null,
  "弱密碼"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux伺服器的Web控制台"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "將被設定為 \"自動\""
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "是"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "您第一次連線到 $0 。"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "您無權修改防火牆。"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "您的瀏覽器不允許從網頁選單貼上。您可以使用 Shift+Insert 。"
 ],
 "Your session has been terminated.": [
  null,
  "您的工作階段已被終止。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "您的工作階段已過期。請再次登入。"
 ],
 "Zone": [
  null,
  "區域"
 ],
 "[binary data]": [
  null,
  "[二進位資料]"
 ],
 "[no data]": [
  null,
  "[沒有資料]"
 ],
 "edit": [
  null,
  "編輯"
 ],
 "in less than a minute": [
  null,
  "於一分鐘內"
 ],
 "less than a minute ago": [
  null,
  "不到一分鐘前"
 ],
 "password quality": [
  null,
  "密碼品質"
 ],
 "show less": [
  null,
  "顯示較少"
 ],
 "show more": [
  null,
  "顯示更多"
 ],
 "wireguard-tools package is not installed": [
  null,
  "wireguard-tools 軟體包未安裝"
 ]
});
