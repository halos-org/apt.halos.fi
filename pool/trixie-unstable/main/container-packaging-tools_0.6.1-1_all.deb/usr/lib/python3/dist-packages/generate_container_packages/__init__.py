"""Container Packaging Tools - Generate Debian packages from container app definitions."""

__version__ = "0.6.1"
__author__ = "Matti Airas"
__license__ = "MIT"
